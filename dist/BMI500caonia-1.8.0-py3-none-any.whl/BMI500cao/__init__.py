__version__ = "0.2.0"

from .module1 import *
